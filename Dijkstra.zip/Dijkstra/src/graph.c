#include "../include/graph.h"

struct graph* createGraph(int n)
{
    struct graph* newGraph = (struct graph*)malloc(sizeof(struct graph));
    newGraph->N = n;
    newGraph->array = (struct adjList*)malloc(n * sizeof(struct adjList));
    for (int i = 0; i < n; i++)
    {
        newGraph->array[i].head = NULL;
    }
    return newGraph;
}

void addEdge(struct graph* graph, int source, int target, int weight)
{
    struct adjListNode* newNode = (struct adjListNode*)malloc(sizeof(struct adjListNode));
    newNode->graph_node_id = target;
    newNode->weight = weight;
    newNode->next = graph->array[source].head;
    graph->array[source].head = newNode;
}

void displayGraph(struct graph* graph, char** cities)
{
    int v;
    for (v = 0; v < graph->N; ++v)
    {
        struct adjListNode* pCrawl = graph->array[v].head;
        printf("%s is connected to:\n", cities[v]);
        while (pCrawl)
        {
            printf("%s\t", cities[pCrawl->graph_node_id]);
            pCrawl = pCrawl->next;
        }
        printf("\n");
    }
}

void freeGraph(struct graph* graph)
{
    if (graph == NULL) {
        return;
    }
    
    for (int i = graph->N - 1; i >= 0 ; i--) {
        struct adjListNode* tmp = graph->array[i].head;

        while(tmp != NULL)
        {
            struct adjListNode*next_temp = tmp->next ;
            free(tmp);
            tmp = next_temp;
        }

    }
    free(graph->array);
    free(graph);
}

void deleteEdge(struct graph* graph, int source, int target)
{
    struct adjListNode* pCrawl = graph->array[source].head;
    if (pCrawl->graph_node_id == target)
    {
        graph->array[source].head = pCrawl->next;
        free(pCrawl);

        pCrawl = NULL;
        return;
    }
    while (pCrawl->next != NULL)
    {
        if (pCrawl->next->graph_node_id == target)
        {
            struct adjListNode* temp = pCrawl->next;
            pCrawl->next = pCrawl->next->next;
            free(temp);
            
            temp = NULL;
            return;
        }
        pCrawl = pCrawl->next;
    }
    if (pCrawl != NULL) {
        free(pCrawl);
        pCrawl = NULL;
    }
}
