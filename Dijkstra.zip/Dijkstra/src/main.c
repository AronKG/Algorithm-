//Aron kesete 

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "../include/heap.h"
#include "../include/graph.h"
//#include <clocale>

//the number of nodes in the graph
#define GRAPH_NODE_N 7
#define INFINITY 9999


//the function that calculates the distances of shortest paths between cities
//parameters: source_node, the id of the source node
//            dist, the minimum distance
//            graph, the graph
void dijkstra(int source_node, int dist[], struct graph* graph, int* kop);

void test_dijkstra(int n);

int main(void)
{
 //   srand(time(0));
    struct graph* graph = createGraph(GRAPH_NODE_N);

    test_dijkstra(100);
    
    test_dijkstra(200);
    
    test_dijkstra(400);
    
    test_dijkstra(800);

    test_dijkstra(1000);

    freeGraph(graph);
   
    return 0;
}




void dijkstra(int source_node, int dist[], struct graph* graph, int* kop)
{
    if(kop == NULL)
        kop = malloc(sizeof(int));
    (*kop) = 0;
    int visited[graph->N];
    for (int i = 0; i < graph->N; i++)
    {
        visited[i] = 0;
        dist[i] = INFINITY;
        dist[source_node] = 0;
    }

    if (source_node >= 0 && source_node < graph->N)
    {
        dist[source_node] = 0;
    }
    else
    {
        printf("Invalid source node index.Need to check the array\n");
        return;
    }

    while (1)
    {
        (*kop)++;
        int min_dist = INFINITY;
        int min_node = -1;
        for (int i = 0; i < graph->N; i++)
        {
            (*kop)++;
            if (visited[i] == 0 && dist[i] < min_dist)
            {
                min_dist = dist[i];
                min_node = i;
            }
        }
        if (min_node == -1)
            break;
        visited[min_node] = 1;
        struct adjListNode* pCrawl = graph->array[min_node].head;
        while (pCrawl)
        {
            (*kop)++;
            if (dist[pCrawl->graph_node_id] > dist[min_node] + pCrawl->weight)
            {
                dist[pCrawl->graph_node_id] = dist[min_node] + pCrawl->weight;
            }
            pCrawl = pCrawl->next;
        }
    }
}


void test_dijkstra(int n)
{
    long long int total = 0;
    for (int i = 1; i <= 10; i++) {
        struct graph* graph_test = createGraph(n);
        for (int i = 1; i <= (n*(n-1)/4);i++)
        {
            int source = rand() % n;
            int target = rand() % n;
            int weight = (rand() % 100) + 1;
            addEdge(graph_test, source, target, weight);  
        }

        int source = rand() % n;
        int dist[n];
        int kop = 0;
        dijkstra(source, dist, graph_test, &kop);
        total += kop;
        freeGraph(graph_test);
    }
    int avg = total / 10;
    printf("%d: %d\n",n,avg);
}


